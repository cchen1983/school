﻿using System;
namespace DecoratorDemo
{
	public class EmptyClass
	{
		public EmptyClass()
		{
		}
	}
}
